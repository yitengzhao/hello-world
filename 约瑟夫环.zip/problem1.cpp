#include<iostream>
using namespace std;
typedef struct pi
{
	int num;
	int count;
	struct pi *next;
 }pi,*List;

void creat(List &L)
{
	L = new pi;
	L->next = NULL;
	List q = L;
	for (int i = 0; i < 13; i++)
	{
		List p = new pi;
		p->count = 0;
		q->next = p;
		p->next = L->next;
		q = q->next;
	}
}

bool isempty(List L)
{
	List q = L->next;
	bool flag = true;
	for (int i = 0; i < 13; i++)
	{
		if (q->count == 0)
		{
			flag = false;
			break;
		}
		q = q->next;
	}
	return flag;
}

int main()
{
	List L;
	creat(L);
	int i = 0;
	int k = 1;
	int counter = 0;
	List p = L->next;
	while (p)
	{
		if(p->count==0)
			i++;
		if (i == k)
		{
			p->num = k;
			p->count = 1;
			i = 0;
			k++;
			if (k > 13)
				k = 1;
		}
		p = p->next;
		if (isempty(L))
			break;
	}
	List q = L->next;
	for (int i = 0; i < 13; i++)
	{
		cout << q->num << " ";
		q = q->next;
	}
}